/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packt.webstore.service;

import com.packt.webstore.domain.Product;
import java.math.BigDecimal;
import java.util.List;
import java.util.Map;

/**
 *
 * @author anhvt
 */
public interface ProductService {
  
  List<Product> getAllProducts();
  
  void updateAllStock();
  
  List<Product> getProductsByCategory(String category);
  
  List<Product> getProductsByFilter(Map<String, List<String>> filterParams);
  
  Product getProductById(String productID);
  
  List<Product> getProductByMultiFilter(String category, 
      Map<String,BigDecimal> priceFilterParams, String brand);
  
  void addProduct(Product product);
}
