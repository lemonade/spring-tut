/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packt.webstore.domain;

import java.util.Objects;

/**
 *
 * @author anhvt
 */
public class Customer {
  private String customerId;
  private String name;
  private String address;
  private int noOfOrdersMade;

  public Customer() { }
  
  public Customer(String customerId, String name, String address) {
    this.customerId = customerId;
    this.name = name;
    this.address = address;
  }

  @Override
  public boolean equals(Object obj) {
    if (this == obj) {
      return true;
    }
    
    if (obj == null) {
      return false;
    }
    
    if (getClass() != obj.getClass()) {
      return false;
    }
    
    Customer other = (Customer) obj;
    
    if (customerId == null) {
      if (other.customerId != null) {
        return false;
      }
    } else if (!customerId.equals(other.customerId)) {
      return false;
    }
    
    return true;
  }

  @Override
  public int hashCode() {
    int hash = 5;
    hash = 17 * hash + Objects.hashCode(this.customerId);
    hash = 17 * hash + Objects.hashCode(this.name);
    hash = 17 * hash + Objects.hashCode(this.address);
    return hash;
  }

  public String getCustomerId() {
    return customerId;
  }

  public void setCustomerId(String customerId) {
    this.customerId = customerId;
  }

  public String getName() {
    return name;
  }

  public void setName(String name) {
    this.name = name;
  }

  public String getAddress() {
    return address;
  }

  public void setAddress(String address) {
    this.address = address;
  }

  public int getNoOfOrdersMade() {
    return noOfOrdersMade;
  }

  public void setNoOfOrdersMade(int noOfOrdersMade) {
    this.noOfOrdersMade = noOfOrdersMade;
  }
}
