/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.packt.webstore.controller;

import com.packt.webstore.domain.Customer;
import com.packt.webstore.service.CustomerService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

/**
 *
 * @author anhvt
 */
@Controller
@RequestMapping("/")
public class CustomerController {
  @Autowired
  private CustomerService customerService;
  
  @RequestMapping("/customers")
  public String list(Model model) {
    model.addAttribute("customers", customerService.getAllCustomers());
    return "customers";
  }
  
  @RequestMapping(value = "/customers/add", method = RequestMethod.GET)
  public String getNewCustomerForm(Model model) {
    Customer newCustomer = new Customer();
    model.addAttribute("newCustomer", newCustomer);
    return "addCustomer";
  }
  
  @RequestMapping(value = "/customers/add", method = RequestMethod.POST)
  public String processAddNewCustomer(@ModelAttribute("newCustomer") Customer customer) {
    customerService.addCustomer(customer);
    return "redirect:/customers";
  }
}
